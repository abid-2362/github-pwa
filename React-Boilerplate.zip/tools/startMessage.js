import {chalkSuccess} from './chalkConfig';

/* eslint-disable no-console */

console.log(chalkSuccess('Starting app in dev mode...'));
