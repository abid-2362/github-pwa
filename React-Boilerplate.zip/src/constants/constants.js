// settings for front end
// export const API_URL = "http://localhost:5000/";
export const API_URL = "";
export const allowedTitleChars = 105;

// USER ACTIONS
export const LOGIN_USER = "LOGIN_USER";
export const LOGIN_USER_CANCEL = "LOGIN_USER_CANCEL";
export const LOGIN_USER_SUCCESS = "LOGIN_USER_SUCCESS";
export const LOGIN_USER_FAILED = "LOGIN_USER_FAILED";
export const REGISTER_USER = "REGISTER_USER";
export const REGISTER_USER_SUCCESS = "REGISTER_USER_SUCCESS";
export const REGISTER_USER_FAILED = "REGISTER_USER_FAILED";
export const REGISTER_USER_CANCEL = "REGISTER_USER_CANCEL";

export const LOGOUT = "LOGOUT";
export const LOGOUT_SUCCESS = "LOGOUT_SUCCESS";