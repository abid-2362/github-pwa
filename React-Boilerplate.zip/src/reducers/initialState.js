export default {
  registrations: [],
  loginUser: {},
  listings: [],
  myListings: [],
  donorListings: [],
  admin: {}
}