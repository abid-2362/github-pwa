// import objectAssign from 'object-assign';
// import initialState from './initialState';
// import * as types from '../constants/constants';

// export default function loginReducer(state = initialState.loginUser, action) {
//   // let newState;

//   switch (action.type) {
//     case types.LOGIN_DONOR_SUCCESS:
//       return action.payload;

//     case types.LOGOUT_SUCCESS:
//       return {}

//     default:
//       return state;
//   }
// }
