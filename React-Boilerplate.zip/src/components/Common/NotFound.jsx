import React from 'react';

const NotFound = () => {
  return(
    <section>
      <div className="container">
        <h2>Errro 404! The page you are looking for is not available</h2>
      </div>
    </section>
  );
};

export default NotFound;
