import jquery from 'jquery';
import '../../assets/js/popper.min.js';
import '../../assets/js/bootstrap.bundle.min.js';