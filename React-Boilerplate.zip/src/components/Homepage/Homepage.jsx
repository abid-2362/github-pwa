import React from 'react';

const Homepage = () => {
  return(
    <div>
      <h2>Home page</h2>
      <p>This is a react boilerplate forked from the cory house repository named as "react slingshot"</p>
    </div>
  );
};
Homepage.defaultProps = {
  // someProp: 'Some Value',
}

Homepage.propTypes = {
  // someValue: PropTypes.string,
}

export default Homepage;
